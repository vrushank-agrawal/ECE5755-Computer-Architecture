#ifndef LAB5_H
#define LAB5_H

#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <stdbool.h>
#include "kernel/kernel.h"
#include "utils/data_utils.h"

#endif // LAB5_H